package qa.seanqagroup.learningApp.model.enums;

public enum E_UserType {
		SYSADMIN,
		LEARNER,
		TRAINER,
		TRAINERMANAGER;
}
