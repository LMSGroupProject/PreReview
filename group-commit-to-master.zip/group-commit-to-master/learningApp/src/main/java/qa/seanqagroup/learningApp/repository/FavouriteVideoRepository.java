package qa.seanqagroup.learningApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import qa.seanqagroup.learningApp.model.FavouriteVideo;

public interface FavouriteVideoRepository extends JpaRepository<FavouriteVideo,Long>{

}
