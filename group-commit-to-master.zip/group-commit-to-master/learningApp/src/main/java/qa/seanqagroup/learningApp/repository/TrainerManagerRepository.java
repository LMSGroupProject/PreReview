package qa.seanqagroup.learningApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import qa.seanqagroup.learningApp.model.TrainerManager;

public interface TrainerManagerRepository extends JpaRepository<TrainerManager,Long>{

}
