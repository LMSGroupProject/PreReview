package qa.seanqagroup.learningApp.tests.model;

public class TQTest {

}
