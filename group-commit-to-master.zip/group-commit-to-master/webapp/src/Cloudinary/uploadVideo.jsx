import React from "react";

export default class uploadVideo extends React.Component{
constructor(props){
    super(props);


}
}